from django.shortcuts import render,HttpResponse,redirect
from home.models import Contact
from blog.models import Post
from django.contrib.auth import authenticate , login , logout
from django.contrib.auth.models import User
from django.contrib import messages

# Create your views here.
def home(request):
    allPosts=Post.objects.all()  # To Fetch all objects
    context={'allPosts':allPosts}
    return render(request,'home/home.html',context)

def about(request):
    return render(request,'home/about.html')

def contact(request):
    if(request.method=='POST'):
        name=request.POST['name']
        email=request.POST['email']
        phone=request.POST['phone']
        content=request.POST['content']
        if(len(name)<2 or len(email)<4 or len(phone)<10 or len(content)<4):
            messages.error(request, 'Please Fill The Form Correctly!')
        else:
            contact=Contact(name=name,email=email,phone=phone,content=content)
            contact.save()
            messages.success(request,'Your Query Has Been submitted! Thanks For Contacting Us')
    return render(request,'home/contact.html')

def search(request):
    query=request.GET['query']

    if(len(query))>78:  #disallowing big queries
        allPosts=Post.objects.none()
    else:
        allPostsTitle=Post.objects.filter(title__icontains=query) 
        allPostsContent=Post.objects.filter(content__icontains=query) 

        allPosts=allPostsTitle.union(allPostsContent)

    if allPosts.count()==0:
         messages.warning(request, ' Oops! No Results Found !')
    params={'allPosts':allPosts,'query':query}
    return render(request,'home/search.html',params)
#authentication    
def handleSignup(request):

    if(request.method=='POST'):
        username = request.POST['username']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']

        # Check for inputs
        if(len(username)>12):
            messages.error(request,"Oops!Username must be under 12 Characters!")
            return redirect('home')
        if not username.isalnum():  #Checked for alpha numeric
            messages.error(request,"Oops!Username should only contain letters and numbers!")
            return redirect('home')
        if(pass1!=pass2):
            messages.error(request,"Oops! Passwords do not match!")
            return redirect('home')
        #Create User
        myuser=User.objects.create_user(username , email , pass1)
        myuser.save()
        messages.success(request,"Congrats! Your iCoder Account Has Been Successfully Created!")
        return redirect('home')
    else:
        return HttpResponse("404 - Not found")

def handleLogin(request):
    if request.method =="POST":
        loginusername=request.POST['loginusername']
        loginpass=request.POST['loginpass']

        #Django given us feature of authentication automatically
        user=authenticate(username=loginusername,password=loginpass)

        if user is not None:
            login(request,user)
            messages.success(request,"Congrats! You Have Successfully Logged In!")
            return redirect('home')
        else:
            messages.warning(request,"Oops! Invalid Credentials! Please Try Again!")
            return redirect('home')
    return HttpResponse("404 - Not Found")

def handleLogout(request):
    logout(request)
    messages.success(request,"You Have Successfully Logged Out!")

    return redirect('home')

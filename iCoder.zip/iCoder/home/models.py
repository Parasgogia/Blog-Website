from django.db import models
from datetime import datetime    
from django.utils.timezone import now



# Create your models here.
class Contact(models.Model):
    sno=models.AutoField(primary_key=True) #autofield means django automatically increment krta jaayega or primarykey means uniquely dentified
    name=models.CharField(max_length=550)
    phone=models.IntegerField()
    email=models.CharField(max_length=100)
    content=models.TextField()


    def __str__(self):
        return 'Message From' +'     '   + self.name + '-' + self.email